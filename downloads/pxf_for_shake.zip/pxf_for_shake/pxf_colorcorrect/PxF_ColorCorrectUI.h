nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_ColorCorrect",PxF_ColorCorrect());
    nuiPopToolBox();
nuiPopMenu();

// Gloabal Sliders

//nuxDefExprToggle("PxF_ColorCorrect.preMultiplied");

//Master Sliders
nuxDefTextCtrl("PxF_ColorCorrect.Mstr_HSC_label", 1);
nuiDefSlider("PxF_ColorCorrect.Mstr_Hue",-360,360);
nuiDefSlider("PxF_ColorCorrect.Mstr_Sat",-1000,1000);
nuiDefSlider("PxF_ColorCorrect.Mstr_Contrast",0,1000);
nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Hue",0,1);
nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Sat",0,1);
nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Val",0,1);
nuxDefTextCtrl("PxF_ColorCorrect.Mstr_GGO_label", 1);
nuiDefSlider("PxF_ColorCorrect.Mstr_RGB_Gamma",0.01,10,0.01,0);
nuiDefSlider("PxF_ColorCorrect.Mstr_RGB_Gain",0,1000,1,0);
nuiDefSlider("PxF_ColorCorrect.Mstr_RGB_Offset",-1,1,0.01,0);
nuiDefSlider("PxF_ColorCorrect.Mstr_R_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Mstr_R_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Mstr_R_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Mstr_G_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Mstr_G_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Mstr_G_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Mstr_B_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Mstr_B_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Mstr_B_Offset",-1,1);

//Shadow Sliders
nuxDefToggle("PxF_ColorCorrect.enableShadows");
nuxDefTextCtrl("PxF_ColorCorrect.Shdw_HSC_label", 1);
nuiDefSlider("PxF_ColorCorrect.Shdw_Hue",-360,360);
nuiDefSlider("PxF_ColorCorrect.Shdw_Sat",-1000,1000);
nuiDefSlider("PxF_ColorCorrect.Shdw_ColorPizza_Hue",0,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_ColorPizza_Sat",0,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_ColorPizza_Val",0,1);
nuxDefTextCtrl("PxF_ColorCorrect.Shdw_GGO_label", 1);
nuiDefSlider("PxF_ColorCorrect.Shdw_RGB_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Shdw_RGB_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Shdw_RGB_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_R_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Shdw_R_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Shdw_R_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_G_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Shdw_G_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Shdw_G_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_B_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Shdw_B_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Shdw_B_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Shdw_Contrast",0,1000);

//Midtone Sliders
nuxDefToggle("PxF_ColorCorrect.enableMidtones");
nuxDefTextCtrl("PxF_ColorCorrect.Midt_HSC_label", 1);
nuiDefSlider("PxF_ColorCorrect.Midt_Hue",-360,360);
nuiDefSlider("PxF_ColorCorrect.Midt_Sat",-1000,1000);
nuiDefSlider("PxF_ColorCorrect.Midt_ColorPizza_Hue",0,1);
nuiDefSlider("PxF_ColorCorrect.Midt_ColorPizza_Sat",0,1);
nuiDefSlider("PxF_ColorCorrect.Midt_ColorPizza_Val",0,1);
nuxDefTextCtrl("PxF_ColorCorrect.Midt_GGO_label", 1);
nuiDefSlider("PxF_ColorCorrect.Midt_RGB_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Midt_RGB_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Midt_RGB_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Midt_R_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Midt_R_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Midt_R_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Midt_G_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Midt_G_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Midt_G_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Midt_B_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Midt_B_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Midt_B_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Midt_Contrast",0,1000);

//Highlight Sliders
nuxDefToggle("PxF_ColorCorrect.enableHighlights");
nuxDefTextCtrl("PxF_ColorCorrect.Hilt_HSC_label", 1);
nuiDefSlider("PxF_ColorCorrect.Hilt_Hue",-360,360);
nuiDefSlider("PxF_ColorCorrect.Hilt_Sat",-1000,1000);
nuiDefSlider("PxF_ColorCorrect.Hilt_ColorPizza_Hue",0,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_ColorPizza_Sat",0,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_ColorPizza_Val",0,1);
nuxDefTextCtrl("PxF_ColorCorrect.Hilt_GGO_label", 1);
nuiDefSlider("PxF_ColorCorrect.Hilt_RGB_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Hilt_RGB_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Hilt_RGB_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_R_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Hilt_R_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Hilt_R_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_G_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Hilt_G_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Hilt_G_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_B_Gamma",0.01,10);
nuiDefSlider("PxF_ColorCorrect.Hilt_B_Gain",0,1000);
nuiDefSlider("PxF_ColorCorrect.Hilt_B_Offset",-1,1);
nuiDefSlider("PxF_ColorCorrect.Hilt_Contrast",0,1000);

//Ranges expressions
nuxDefToggle("PxF_ColorCorrect.showRanges");
nuiDefSlider("PxF_ColorCorrect.RangeShdwCutoff",0,1);
nuiDefSlider("PxF_ColorCorrect.RangeShdwTngt",-100,100);
nuiDefSlider("PxF_ColorCorrect.RangeHiltCutoff",0,1);
nuiDefSlider("PxF_ColorCorrect.RangeHiltTngt",-100,100);

nuxDefTextCtrl("PxF_ColorCorrect.version", 0);



// Plumbing

//nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Hue",0,1);
//nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Sat",0,1);
//nuiDefSlider("PxF_ColorCorrect.Mstr_ColorPizza_Val",0,1);


//Master Group
nuiPushControlGroup("PxF_ColorCorrect.Master");
	nuiGroupControl("PxF_ColorCorrect.Mstr_HSC_label");
    nuiPushControlGroup("Mstr_HSC");
        nuiGroupControl("PxF_ColorCorrect.Mstr_Hue");
        nuiGroupControl("PxF_ColorCorrect.Mstr_Sat");
        nuiGroupControl("PxF_ColorCorrect.Mstr_Contrast");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_HSC",nuiConnectXYZTriplet());
    
    nuiPushControlGroup("Mstr_Tint");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Hue");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Sat");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Val");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_Tint", nuiConnectColorTriplet(kHSVToggle,kCurrentColor,1));
    
    nuiGroupControl("PxF_ColorCorrect.Mstr_GGO_label");

    nuiPushControlGroup("Mstr_RGB");
        nuiGroupControl("PxF_ColorCorrect.Mstr_RGB_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Mstr_RGB_Gain");
        nuiGroupControl("PxF_ColorCorrect.Mstr_RGB_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_RGB",nuiConnectXYZTriplet());

    nuiPushControlGroup("Mstr_R");
        nuiGroupControl("PxF_ColorCorrect.Mstr_R_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Mstr_R_Gain");
        nuiGroupControl("PxF_ColorCorrect.Mstr_R_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_R",nuiConnectXYZTriplet());

    nuiPushControlGroup("Mstr_G");    
        nuiGroupControl("PxF_ColorCorrect.Mstr_G_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Mstr_G_Gain");
        nuiGroupControl("PxF_ColorCorrect.Mstr_G_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_G",nuiConnectXYZTriplet());

    nuiPushControlGroup("Mstr_B");    
        nuiGroupControl("PxF_ColorCorrect.Mstr_B_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Mstr_B_Gain");
        nuiGroupControl("PxF_ColorCorrect.Mstr_B_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_B",nuiConnectXYZTriplet());
nuiPopControlGroup();

// Shadows group
nuiPushControlGroup("PxF_ColorCorrect.Shadows");
    nuiGroupControl("PxF_ColorCorrect.enableShadows");
    nuiGroupControl("PxF_ColorCorrect.Shdw_HSC_label");
    nuiPushControlGroup("Shdw_HSC");
        nuiGroupControl("PxF_ColorCorrect.Shdw_Hue");
        nuiGroupControl("PxF_ColorCorrect.Shdw_Sat");
        nuiGroupControl("PxF_ColorCorrect.Shdw_Contrast");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_HSC",nuiConnectXYZTriplet());
    
    nuiPushControlGroup("Shdw_Tint");
        nuiGroupControl("PxF_ColorCorrect.Shdw_ColorPizza_Hue");
        nuiGroupControl("PxF_ColorCorrect.Shdw_ColorPizza_Sat");
        nuiGroupControl("PxF_ColorCorrect.Shdw_ColorPizza_Val");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_Tint", nuiConnectColorTriplet(kHSVToggle,kCurrentColor,1));
    
    nuiGroupControl("PxF_ColorCorrect.Shdw_GGO_label");

    nuiPushControlGroup("Shdw_RGB");
        nuiGroupControl("PxF_ColorCorrect.Shdw_RGB_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Shdw_RGB_Gain");
        nuiGroupControl("PxF_ColorCorrect.Shdw_RGB_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_RGB",nuiConnectXYZTriplet());

    nuiPushControlGroup("Shdw_R");
        nuiGroupControl("PxF_ColorCorrect.Shdw_R_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Shdw_R_Gain");
        nuiGroupControl("PxF_ColorCorrect.Shdw_R_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_R",nuiConnectXYZTriplet());

    nuiPushControlGroup("Shdw_G");    
        nuiGroupControl("PxF_ColorCorrect.Shdw_G_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Shdw_G_Gain");
        nuiGroupControl("PxF_ColorCorrect.Shdw_G_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_G",nuiConnectXYZTriplet());

    nuiPushControlGroup("Shdw_B");    
        nuiGroupControl("PxF_ColorCorrect.Shdw_B_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Shdw_B_Gain");
        nuiGroupControl("PxF_ColorCorrect.Shdw_B_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Shdw_B",nuiConnectXYZTriplet());
nuiPopControlGroup();

// Midtones Group
nuiPushControlGroup("PxF_ColorCorrect.Midtones");
    nuiGroupControl("PxF_ColorCorrect.enableMidtones");
    nuiGroupControl("PxF_ColorCorrect.Midt_HSC_label");
    nuiPushControlGroup("Midt_HSC");
        nuiGroupControl("PxF_ColorCorrect.Midt_Hue");
        nuiGroupControl("PxF_ColorCorrect.Midt_Sat");
        nuiGroupControl("PxF_ColorCorrect.Midt_Contrast");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_HSC",nuiConnectXYZTriplet());
    
    nuiPushControlGroup("Midt_Tint");
        nuiGroupControl("PxF_ColorCorrect.Midt_ColorPizza_Hue");
        nuiGroupControl("PxF_ColorCorrect.Midt_ColorPizza_Sat");
        nuiGroupControl("PxF_ColorCorrect.Midt_ColorPizza_Val");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_Tint", nuiConnectColorTriplet(kHSVToggle,kCurrentColor,1));
    
    nuiPushControlGroup("Midt_RGB");
        nuiGroupControl("PxF_ColorCorrect.Midt_RGB_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Midt_RGB_Gain");
        nuiGroupControl("PxF_ColorCorrect.Midt_RGB_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_RGB",nuiConnectXYZTriplet());
    
    nuiGroupControl("PxF_ColorCorrect.Midt_GGO_label");


    nuiPushControlGroup("Midt_R");
        nuiGroupControl("PxF_ColorCorrect.Midt_R_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Midt_R_Gain");
        nuiGroupControl("PxF_ColorCorrect.Midt_R_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_R",nuiConnectXYZTriplet());

    nuiPushControlGroup("Midt_G");    
        nuiGroupControl("PxF_ColorCorrect.Midt_G_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Midt_G_Gain");
        nuiGroupControl("PxF_ColorCorrect.Midt_G_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_G",nuiConnectXYZTriplet());

    nuiPushControlGroup("Midt_B");    
        nuiGroupControl("PxF_ColorCorrect.Midt_B_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Midt_B_Gain");
        nuiGroupControl("PxF_ColorCorrect.Midt_B_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Midt_B",nuiConnectXYZTriplet());
nuiPopControlGroup();

// Highlights Group
nuiPushControlGroup("PxF_ColorCorrect.Highlights");
    nuiGroupControl("PxF_ColorCorrect.enableHighlights");
    nuiGroupControl("PxF_ColorCorrect.Hilt_HSC_label");
    nuiPushControlGroup("Hilt_HSC");
        nuiGroupControl("PxF_ColorCorrect.Hilt_Hue");
        nuiGroupControl("PxF_ColorCorrect.Hilt_Sat");
        nuiGroupControl("PxF_ColorCorrect.Hilt_Contrast");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_HSC",nuiConnectXYZTriplet());
    
    nuiPushControlGroup("Hilt_Tint");
        nuiGroupControl("PxF_ColorCorrect.Hilt_ColorPizza_Hue");
        nuiGroupControl("PxF_ColorCorrect.Hilt_ColorPizza_Sat");
        nuiGroupControl("PxF_ColorCorrect.Hilt_ColorPizza_Val");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_Tint", nuiConnectColorTriplet(kHSVToggle,kCurrentColor,1));
    
    nuiGroupControl("PxF_ColorCorrect.Hilt_GGO_label");

    nuiPushControlGroup("Hilt_RGB");
        nuiGroupControl("PxF_ColorCorrect.Hilt_RGB_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Hilt_RGB_Gain");
        nuiGroupControl("PxF_ColorCorrect.Hilt_RGB_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_RGB",nuiConnectXYZTriplet());

    nuiPushControlGroup("Hilt_R");
        nuiGroupControl("PxF_ColorCorrect.Hilt_R_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Hilt_R_Gain");
        nuiGroupControl("PxF_ColorCorrect.Hilt_R_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_R",nuiConnectXYZTriplet());

    nuiPushControlGroup("Hilt_G");    
        nuiGroupControl("PxF_ColorCorrect.Hilt_G_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Hilt_G_Gain");
        nuiGroupControl("PxF_ColorCorrect.Hilt_G_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_G",nuiConnectXYZTriplet());

    nuiPushControlGroup("Hilt_B");    
        nuiGroupControl("PxF_ColorCorrect.Hilt_B_Gamma");
        nuiGroupControl("PxF_ColorCorrect.Hilt_B_Gain");
        nuiGroupControl("PxF_ColorCorrect.Hilt_B_Offset");
    nuiPopControlGroup();
    nuiPushControlWidget("Hilt_B",nuiConnectXYZTriplet());
nuiPopControlGroup();


nuiPushControlGroup("PxF_ColorCorrect.Ranges");
    nuiGroupControl("PxF_ColorCorrect.showRanges");
    nuiGroupControl("PxF_ColorCorrect.RangeShdwCutoff");
    nuiGroupControl("PxF_ColorCorrect.RangeShdwTngt");
    nuiGroupControl("PxF_ColorCorrect.RangeHiltCutoff");
    nuiGroupControl("PxF_ColorCorrect.RangeHiltTngt");
nuiPopControlGroup();

/*
nuiPushControlGroup("PxF_ColorCorrect.PlumbingKeepOut");
    nuiPushControlGroup("Mstr_ColorTintPlumbing");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Hue");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Sat");
        nuiGroupControl("PxF_ColorCorrect.Mstr_ColorPizza_Val");
    nuiPopControlGroup();
    nuiPushControlWidget("Mstr_ColorTintPlumbing", nuiConnectColorTriplet(kHSVToggle,kCurrentColor,1));
nuiPopControlGroup();*/
