nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_Lens",PxF_Lens());
    nuiPopToolBox();
nuiPopMenu();

nuxDefRadioBtnOCtrl("PxF_Lens.lensChannel",1, 1, 0, "R|ux/radio/radio_red", "G|ux/radio/radio_green", "B|ux/radio/radio_blue", "A|ux/radio/radio_alpha");
nuxDefMultiChoice("PxF_Lens.channels","RGBA|RGB|A");
nuxDefRadioBtnOCtrl("PxF_Lens.channels", 0, 1, 0, "0|RGBA", "1|RGB", "2|A");
nuiDefSlider("PxF_Lens.amount",-2,2,0);

nuxDefToggle("PxF_Lens.fine");
nuiDefSlider("PxF_Lens.blurLens",0,480,0);
//nuiDefSlider("PxF_Lens.rotateWarpDir",-180,180,0);


nuxDefMultiChoice("PxF_Lens.wrap","no|tile|reflect");
nuxDefRadioBtnOCtrl("PxF_Lens.wrap", 0, 1, 0, "0|no", "1|tile", "2|reflect");

nuxDefToggle("PxF_Lens.filterLens");
nuiDefSlider("PxF_Lens.oversample",1,4,1);
nuiDefSlider("PxF_Lens.pixelAspect",0.5,2.5,0);
nuiDefSlider("PxF_Lens.delta",1,5000,0);
nuiDefSlider("PxF_Lens.blurGainBias",0.1,2,0);

nuiPushControlGroup("PxF_Lens.Advanced");
    nuiGroupControl("PxF_Lens.delta");
    nuiGroupControl("PxF_Lens.blurGainBias");
nuiPopControlGroup();

nuxDefTextCtrl("PxF_Lens.version", 1);
