/* PxF_Lens 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	"Cambridge-style" image based deformation.

Used for:
	Distortions, reflections, refractions and "growing" an image to push matte lines outside the
	matte. 

Controls:
	lensChannel:
		Select which channel of the "Lens" input image will be used to create the deformation map.
	channels:
		Select which channels will be deformed.

	amount:
		Intensity of the deformation.

	fine:
		Divides "amount" by 100 internally for finer adjustement of small deformation values.

	blurLens:
		Blur the deformation map and compensate the gain. Using this control is NOT the same as
		bluring the "Lens" input image.

	wrap:
		If pixels need to be fetched outside the frame, wrap determines how to get them.
            no:
				Outside pixels are black. Fastest option.
            
            tile:
				The source image is tiled. You won't get black holes in the deformation, but you
				might see the seam between the edges of the tiled frames. 
            
            reflect:
				The source image is flipped/flopped then tiled. This hides the seam between the
				edges. This is the slowest option.
                 
	filterLens:
		Renders the deformation 5 times with slightly shifted versions of the deformation map, then
		averages all 5 results to create anti-aliasing. This will slow down the render times quite
		a bit.

	oversample:
		Upscales both the Source and Lens images by the oversample factor, then downscales the
		deformed result with filtering to create anti-aliasing. This will slow down render times,
		but probably not as much as "filterLens".

	pixelAspect:
		This is pixel aspect ratio bias for the blurLens parameter. Use this if you have anamorphic
		images.

	Advanced:
		delta:
			This is the "delta" value used in the DisplaceX nodes used inside this macro. Set too
			low, black blocks will appear in the result. The Shake user guide says that setting this
			value "too high" will impede performance. Casual testing hasn't shown a noticable
			difference between "big" and "small" deltas. The default is set pretty high (5000) to
			avoid artifacts.
				
		blurGainBias:
			This is a fudge factor used when boosting the gain of the deformation map as the
			blurLens value increases. Might be fun to play with it for creative purposes.

*/

image PxF_Lens(
image Source=0,
image Lens=0,
const char *lensChannel="A",
int channels=0,
float amount=1,
int fine=0,
float blurLens=20,
int wrap=0,
int filterLens=0,
float oversample=1,
float pixelAspect=1,
int delta=5000,
float blurGainBias=0.395,
const char *version = "PxF_Lens 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"
)
{
    
    float amount2 = 1.0f;
    
    
    
    if (fine == 1) {
    	amount2 = amount * 0.01f;
    } else {
    	amount2 = amount;
    }
    
    if (lensChannel == "R") {
    	Reorder1 = Reorder(Lens, "rrr");
    } else if (lensChannel == "G") {
    	Reorder1 = Reorder(Lens, "ggg");
    } else if (lensChannel == "B") {
    	Reorder1 = Reorder(Lens, "bbb");
    } else if (lensChannel == "A") {
    	Reorder1 = Reorder(Lens, "aaa");
    }
    
    Bytes1 = Bytes(Reorder1, 4);
    
    if (oversample != 1) {
    	Resize1 = Resize(Source, width * oversample, height * oversample, "box", 0);
    } else {
    	Resize1 = Source;
    }
    Pan1 = Pan(Bytes1, 1, 0, 0, 0.5, 0);
    Pan2 = Pan(Bytes1, 0, 1, 0, 0.5, 0);
    ISub1 = ISub(Pan2, Bytes1, 1, 100);
    ISub2 = ISub(Pan1, Bytes1, 1, 100);
    Copy1 = Copy(ISub2, ISub1, 1, "g", 0);
    Blur2 = Blur(Copy1, blurLens * 2.75, blurLens * 2.75 * pixelAspect, 0, "gauss", xFilter, "rgba");
    Brightness1 = Brightness(Blur2, pow(blurLens,blurGainBias));
    
    if (oversample != 1) {
    	Resize6 = Resize(Brightness1, width * oversample, height * oversample, "default", 0);
    } else {
    	Resize6 = Brightness1;
    }
    

    
    if (wrap == 0) {
    	DisplaceX1 = DisplaceX(Resize1, Resize6, 0,  x - (r * strength) , y - (g * strength), delta, delta, float strength= amount2 * width * 3.597);
    } else if (wrap == 1) {
    	DisplaceX1 = DisplaceX(Resize1, Resize6, 0,  
						{{ 
						
						h = (r * strength);
						j = (x - h) ;
						h == 0.0 ?
							x :
						j < 0 ? 
							width + (j % width) : 
						/*else*/
						        j % width; 
						}},
						
						{{  
						h = (g * strength);
						j = (y - h);
						h == 0.0 ?
							y :    
						j < 0 ? 
						    	height + (j % height) : 
						/*else*/
							j % height; 
						}}, 
							
						delta, delta, float strength= amount2 * width * 3.597);
    } else if (wrap == 2) {
    	DisplaceX1 = DisplaceX(Resize1, Resize6, 0,  
						
						{{
						h = (r * strength);
						j = (x - h);
						
						h == 0.0 ? 
							x :
						j <= 0 && fabs(floor(j/width) % 2) > 0 ? 
							(j % width) * -1 : 
						j <= 0 ?
							width + (j % width) :
						j  > width && floor(j/width) % 2 > 0?
							width - (j % width) :
						j  > width ?
							(j % width):
						/*else*/
							j; 
						}}, 
						
						
						{{
						h = (g * strength) ;
						j = (y - h) ;
						
						h == 0.0 ?
							y :
						j <= 0 && fabs(floor(j/height) % 2) > 0? 
							(j % height) * -1 : 
						j <= 0 ?
							height + (j % height) :
						j  > height && floor(j/height) % 2 > 0?
							height - (j % height) :
						j  > height ?
							(j % height):
						/*else*/
							j;
						}},
						delta, delta, float strength= amount2 * width * 3.597);
    }
   
    
    if (filterLens) {
	Pan3 = Pan(Resize6, -1, 0, 0, 0.5, 0);
	Pan4 = Pan(Resize6, 1, 0, 0, 0.5, 0);
	Pan5 = Pan(Resize6, 0, -1, 0, 0.5, 0);
	Pan6 = Pan(Resize6, 0, 1, 0, 0.5, 0);
	
	    if (wrap == 0) {
    		DisplaceX2 = DisplaceX(Resize1, Pan4, 0,  x - (r * strength) , y - (g * strength), delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX3 = DisplaceX(Resize1, Pan5, 0,  x - (r * strength) , y - (g * strength), delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX4 = DisplaceX(Resize1, Pan6, 0,  x - (r * strength) , y - (g * strength), delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX6 = DisplaceX(Resize1, Pan3, 0,  x - (r * strength) , y - (g * strength), delta, delta, float strength= amount2 * width * 3.597);

	    } else if (wrap == 1) {
    		DisplaceX2 = DisplaceX(Resize1, Pan4, 0,  (x - (r * strength)) < 0 ? width + ((x - (r * strength)) % width) : (x - (r * strength)) % width , (y - (g * strength)) < 0 ? height + ((y - (g * strength)) % height) : (y - (g * strength)) % height , delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX3 = DisplaceX(Resize1, Pan5, 0,  (x - (r * strength)) < 0 ? width + ((x - (r * strength)) % width) : (x - (r * strength)) % width , (y - (g * strength)) < 0 ? height + ((y - (g * strength)) % height) : (y - (g * strength)) % height , delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX4 = DisplaceX(Resize1, Pan6, 0,  (x - (r * strength)) < 0 ? width + ((x - (r * strength)) % width) : (x - (r * strength)) % width , (y - (g * strength)) < 0 ? height + ((y - (g * strength)) % height) : (y - (g * strength)) % height , delta, delta, float strength= amount2 * width * 3.597);
    		DisplaceX6 = DisplaceX(Resize1, Pan3, 0,  (x - (r * strength)) < 0 ? width + ((x - (r * strength)) % width) : (x - (r * strength)) % width , (y - (g * strength)) < 0 ? height + ((y - (g * strength)) % height) : (y - (g * strength)) % height , delta, delta, float strength= amount2 * width * 3.597);

	    } else if (wrap == 2) {
    		DisplaceX2 = DisplaceX(Resize1, Pan4, 0,  


							(x - (r * strength)) <= 0 && fabs(floor((x - (r * strength))/width) % 2) > 0 ? 
								((x - (r * strength)) % width) * -1 : 
							(x - (r * strength)) <= 0 ?
								width + ((x - (r * strength)) % width) :
							(x - (r * strength))  > width && floor((x - (r * strength))/width) % 2 > 0?
								width - ((x - (r * strength)) % width) :
							(x - (r * strength))  > width ?
								((x - (r * strength)) % width):

								(x - (r * strength)), 



							(y - (g * strength)) <= 0 && fabs(floor((y - (g * strength))/height) % 2) > 0? 
								((y - (g * strength)) % height) * -1 : 
							(y - (g * strength)) <= 0 ?
								height + ((y - (g * strength)) % height) :
							(y - (g * strength))  > height && floor((y - (g * strength))/height) % 2 > 0?
								height - ((y - (g * strength)) % height) :
							(y - (g * strength))  > height ?
								((y - (g * strength)) % height):

								(y - (g * strength)),
							delta, delta, float strength= amount2 * width * 3.597);

    		DisplaceX3 = DisplaceX(Resize1, Pan5, 0,  


							(x - (r * strength)) <= 0 && fabs(floor((x - (r * strength))/width) % 2) > 0 ? 
								((x - (r * strength)) % width) * -1 : 
							(x - (r * strength)) <= 0 ?
								width + ((x - (r * strength)) % width) :
							(x - (r * strength))  > width && floor((x - (r * strength))/width) % 2 > 0?
								width - ((x - (r * strength)) % width) :
							(x - (r * strength))  > width ?
								((x - (r * strength)) % width):

								(x - (r * strength)), 



							(y - (g * strength)) <= 0 && fabs(floor((y - (g * strength))/height) % 2) > 0? 
								((y - (g * strength)) % height) * -1 : 
							(y - (g * strength)) <= 0 ?
								height + ((y - (g * strength)) % height) :
							(y - (g * strength))  > height && floor((y - (g * strength))/height) % 2 > 0?
								height - ((y - (g * strength)) % height) :
							(y - (g * strength))  > height ?
								((y - (g * strength)) % height):

								(y - (g * strength)),
							delta, delta, float strength= amount2 * width * 3.597);

    		DisplaceX4 = DisplaceX(Resize1, Pan6, 0,  


							(x - (r * strength)) <= 0 && fabs(floor((x - (r * strength))/width) % 2) > 0 ? 
								((x - (r * strength)) % width) * -1 : 
							(x - (r * strength)) <= 0 ?
								width + ((x - (r * strength)) % width) :
							(x - (r * strength))  > width && floor((x - (r * strength))/width) % 2 > 0?
								width - ((x - (r * strength)) % width) :
							(x - (r * strength))  > width ?
								((x - (r * strength)) % width):

								(x - (r * strength)), 



							(y - (g * strength)) <= 0 && fabs(floor((y - (g * strength))/height) % 2) > 0? 
								((y - (g * strength)) % height) * -1 : 
							(y - (g * strength)) <= 0 ?
								height + ((y - (g * strength)) % height) :
							(y - (g * strength))  > height && floor((y - (g * strength))/height) % 2 > 0?
								height - ((y - (g * strength)) % height) :
							(y - (g * strength))  > height ?
								((y - (g * strength)) % height):

								(y - (g * strength)),
							delta, delta, float strength= amount2 * width * 3.597);

    		DisplaceX6 = DisplaceX(Resize1, Pan3, 0,  


							(x - (r * strength)) <= 0 && fabs(floor((x - (r * strength))/width) % 2) > 0 ? 
								((x - (r * strength)) % width) * -1 : 
							(x - (r * strength)) <= 0 ?
								width + ((x - (r * strength)) % width) :
							(x - (r * strength))  > width && floor((x - (r * strength))/width) % 2 > 0?
								width - ((x - (r * strength)) % width) :
							(x - (r * strength))  > width ?
								((x - (r * strength)) % width):

								(x - (r * strength)), 



							(y - (g * strength)) <= 0 && fabs(floor((y - (g * strength))/height) % 2) > 0? 
								((y - (g * strength)) % height) * -1 : 
							(y - (g * strength)) <= 0 ?
								height + ((y - (g * strength)) % height) :
							(y - (g * strength))  > height && floor((y - (g * strength))/height) % 2 > 0?
								height - ((y - (g * strength)) % height) :
							(y - (g * strength))  > height ?
								((y - (g * strength)) % height):

								(y - (g * strength)),
							delta, delta, float strength= amount2 * width * 3.597);
	    }

	
	
	
	
	Mix2 = Mix(DisplaceX1, DisplaceX6, 1, 50, "rgba"); 
	Mix3 = Mix(Mix2, DisplaceX2, 1, 33.3, "rgba");
	Mix4 = Mix(Mix3, DisplaceX3, 1, 25, "rgba");
	Mix5 = Mix(Mix4, DisplaceX4, 1, 20, "rgba");
    } else {
    	Mix5 = DisplaceX1;
    }
    
    if (oversample != 1) {
    	downsample = Resize(Mix5, width / oversample, height / oversample, "default", 0);
    } else {
    	downsample = Mix5;
    }
    
    if (channels == 0) {
    	SwitchMatte1 = downsample;
    } else if (channels == 1) {
    	SwitchMatte1 = SwitchMatte(downsample, Source, 1, "A", 0, 0);
    } else if (channels == 2) {
    	SwitchMatte1 = SwitchMatte(Source, downsample, 1, "A", 0, 0);
	}
    
    return SwitchMatte1;
}

