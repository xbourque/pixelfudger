/* PxF_BandPass 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	"Cambridge-style" BandPass filter.
	The difference between two blurs of the same image.

Used for:
	Isolating detail in an image, making plates easier to track.
	Also used in conjunction with the SoftLight transfer mode to add detail back to a plate that 
	needs sharpening.

Controls:
	blurAmount1, blurAmount2:
		The size of each of the blurs being applied to the image before substraction. 

	blurRelX, blurRelY:
		Aspect ratio controls of the blurs for anamorphic plates.

	brightness:
		Overall gain applied after the two blurs have been subtracted from one another.

	saturation:
		Overall saturation of the result.

	offsetDarks:
		The value that the pixels with "no detail" will have. No matter the original color of an 
		area of the image, if it contains no details it will be turned to this color.

*/

image PxF_BandPass(
image In=0,
float blurAmount1=27,
float blurAmount2=54,
float blurRelX=1,
float blurRelY=1,
float brightness=5,
float saturation=1,
float offsetDarks=0.5,
const char *version = "PxF_BandPass 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"
)
{
    Bytes1 = Bytes(In, 4);
    Saturation1 = Saturation(Bytes1, saturation);
    Blur1 = Blur(Saturation1, (blurAmount1 * blurRelX), (blurAmount1 * blurRelY), 0, "gauss", "gauss", "rgba");
    Blur2 = Blur(Saturation1, (blurAmount2 * blurRelX), (blurAmount2 * blurRelY), 0, "gauss", "gauss", "rgba");
    ISub1 = ISub(Blur1, Blur2, 1, 100);
    Brightness1 = Brightness(ISub1, brightness);
    Add1 = Add(Brightness1, offsetDarks, offsetDarks, offsetDarks, 0, 0);
    Bytes2 = Bytes(Add1, Bytes1.In.bytes);
    SwitchMatte1 = SwitchMatte(Bytes2, In, 1, "A", 0, 0);
    
    
    return SwitchMatte1;
}

