nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_BandPass",PxF_BandPass());
    nuiPopToolBox();
nuiPopMenu();

nuiDefSlider("PxF_BandPass.blurAmount1",0,200,0.1);
nuiDefSlider("PxF_BandPass.blurAmount2",0,200,0.1);
nuiDefSlider("PxF_BandPass.blurRelX",0,5,0.1);
nuiDefSlider("PxF_BandPass.blurRelY",0,5,0.1);
nuiDefSlider("PxF_BandPass.brightness",-50,50,0);
nuiDefSlider("PxF_BandPass.saturation",0,2,0);
nuiDefSlider("PxF_BandPass.offsetDarks",0,1,0);

nuxDefTextCtrl("PxF_BandPass.version", 1);

