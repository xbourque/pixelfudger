Installation instructions:

Create missing directories if needed.

Put the .nri (icon) file here:

/Users/<your user here>/nreal/icons/

Put the .h (macro) file here:

/Users/<your user here>/nreal/include/startup/

Put the UI.h (user interface) file here:

/Users/<your user here>/nreal/include/startup/ui/

Licensing:

This macro is distributed as freeware. This means you can use this macro in any way you like (including commercial usage) free of charge. However, please do not remove or modify the copyright information included inside the macro files.

(c) 2007 - Xavier Bourque - www.pixelfudger.com
