nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_Keyer",PxF_Keyer());
    nuiPopToolBox();
nuiPopMenu();

nuiDefSlider("PxF_Keyer.KeyCenterR",0,1);
nuiDefSlider("PxF_Keyer.KeyCenterG",0,1);
nuiDefSlider("PxF_Keyer.KeyCenterB",0,1);
nuiPushControlGroup("PxF_Keyer.KeyCenter");
    nuiGroupControl("PxF_Keyer.KeyCenterR");
    nuiGroupControl("PxF_Keyer.KeyCenterG");
    nuiGroupControl("PxF_Keyer.KeyCenterB");
nuiPopControlGroup();
nuiPushControlWidget("PxF_Keyer.KeyCenter", nuiConnectColorTriplet(kRGBToggle,kAverageColor,1));


nuiDefSlider("PxF_Keyer.PlotR",0,1);
nuiDefSlider("PxF_Keyer.PlotG",0,1);
nuiDefSlider("PxF_Keyer.PlotB",0,1);
nuiPushControlGroup("PxF_Keyer.Plot");
    nuiGroupControl("PxF_Keyer.PlotR");
    nuiGroupControl("PxF_Keyer.PlotG");
    nuiGroupControl("PxF_Keyer.PlotB");
nuiPopControlGroup();
nuiPushControlWidget("PxF_Keyer.Plot", nuiConnectColorTriplet(kRGBToggle,kCurrentColor,1));

nuxDefMultiChoice("PxF_Keyer.KeyerMode","rgb|yuv|hsv");
nuxDefMultiChoice("PxF_Keyer.ChannelCombine","max|screen");

nuxDefToggle("PxF_Keyer.invertMatte");

nuxDefToggle("PxF_Keyer.matteMult");

nuxDefToggle("PxF_Keyer.enableOSC");

nuxDefToggle("PxF_Keyer.enableChan1");
nuiDefSlider("PxF_Keyer.Chan1_Min_Tol",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan1_Max_Tol",0,1,0.01);
nuiPushControlGroup("Chan1_Tol");
    nuiGroupControl("PxF_Keyer.Chan1_Min_Tol");
    nuiGroupControl("PxF_Keyer.Chan1_Max_Tol");
nuiPopControlGroup();
nuiPushControlWidget("Chan1_Tol",nuiConnectXYZTriplet());

nuiDefSlider("PxF_Keyer.Chan1_Min_Soft",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan1_Max_Soft",0,1,0.01);
nuiPushControlGroup("Chan1_Soft");
    nuiGroupControl("PxF_Keyer.Chan1_Min_Soft");
    nuiGroupControl("PxF_Keyer.Chan1_Max_Soft");
nuiPopControlGroup();
nuiPushControlWidget("Chan1_Soft",nuiConnectXYZTriplet());

nuxDefToggle("PxF_Keyer.enableChan2");
nuiDefSlider("PxF_Keyer.Chan2_Min_Tol",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan2_Max_Tol",0,1,0.01);
nuiPushControlGroup("Chan2_Tol");
    nuiGroupControl("PxF_Keyer.Chan2_Min_Tol");
    nuiGroupControl("PxF_Keyer.Chan2_Max_Tol");
nuiPopControlGroup();
nuiPushControlWidget("Chan2_Tol",nuiConnectXYZTriplet());

nuxDefToggle("PxF_Keyer.enableChan3");
nuiDefSlider("PxF_Keyer.Chan2_Min_Soft",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan2_Max_Soft",0,1,0.01);
nuiPushControlGroup("Chan2_Soft");
    nuiGroupControl("PxF_Keyer.Chan2_Min_Soft");
    nuiGroupControl("PxF_Keyer.Chan2_Max_Soft");
nuiPopControlGroup();
nuiPushControlWidget("Chan2_Soft",nuiConnectXYZTriplet());


nuiDefSlider("PxF_Keyer.Chan3_Min_Tol",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan3_Max_Tol",0,1,0.01);
nuiPushControlGroup("Chan3_Tol");
    nuiGroupControl("PxF_Keyer.Chan3_Min_Tol");
    nuiGroupControl("PxF_Keyer.Chan3_Max_Tol");
nuiPopControlGroup();
nuiPushControlWidget("Chan3_Tol",nuiConnectXYZTriplet());

nuiDefSlider("PxF_Keyer.Chan3_Min_Soft",0,1,0.01);
nuiDefSlider("PxF_Keyer.Chan3_Max_Soft",0,1,0.01);
nuiPushControlGroup("Chan3_Soft");
    nuiGroupControl("PxF_Keyer.Chan3_Min_Soft");
    nuiGroupControl("PxF_Keyer.Chan3_Max_Soft");
nuiPopControlGroup();
nuiPushControlWidget("Chan3_Soft",nuiConnectXYZTriplet());

nuxDefTextCtrl("PxF_Keyer.version", 1);