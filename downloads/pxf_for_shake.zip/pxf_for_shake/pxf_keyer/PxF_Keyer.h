/* PxF_Keyer 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	"Montreal-style" keyer.

Used for:
	Generating alpha channels from arbitrary colors.
	
Controls:
	KeyCenter:
		This color pot determines which color is the "center" of the key. For example on a blue
		screen, this should be the average blue of the screen.
	
	Plot:
		Has no effect on the resulting key. This color is plotted as a red line on the OSC (see
		OSC, below).
		
	Mode:
		Selects which colorspace is used for keying.
			rgb: Red, Green and Blue.
			yuv: Luminance (y) and chroma difference channels (u and v).
			hsv: Hue, Saturation and Value. Similar to HLS mode in other software packages.
	
	ChannelCombine:
		Internally, channels are keyed individually, then combined into a single alpha channel using
		this method.
			max: Returns the max value of the 3 key channels.
			screen: Screens all 3 channels together. Usually gives softer edges than "max".
			
	InvertMatte:
		Inverts the resulting alpha channel.
	
	MatteMult:
		Multiplies the RGB values of the input image by the resulting alpha channel.
		
	enableOSC:
		Enables the On Screen Controls. This shows a visual representation of the key channels.
		Cyan lines represent key tolerance.
		Yellow lines represent key softness.
		
		WARNING!: Don't forget to turn off the OSC before rendering, as the OSC will be rendered on
		top of your image if leave it on.
		
	enableChan1/2/3:
		Allows you to turn on or off any key channel.
	
	Chan1/2/3_Tol:
		Sets the high and low values between which pixels are considered fully transparent for each
		key channel.
	
	Chan1/2/3_Soft:
		Sets the high and low values between which pixels are considered semi-transparent for each
		key channel.
*/

image PxF_Keyer(
image input=0,
float KeyCenterR=0,
float KeyCenterG=0,
float KeyCenterB=0,

float PlotR=0,
float PlotG=0,
float PlotB=0,

char *KeyerMode="rgb",
char *ChannelCombine="max",

int invertMatte=0,

int matteMult=1,

int enableOSC=0,

int enableChan1=1,
float Chan1_Min_Tol=0,
float Chan1_Max_Tol=0,
float Chan1_Min_Soft=0.2,
float Chan1_Max_Soft=0.2,

int enableChan2=1,
float Chan2_Min_Tol=0,
float Chan2_Max_Tol=0,
float Chan2_Min_Soft=0.2,
float Chan2_Max_Soft=0.2,

int enableChan3=1,
float Chan3_Min_Tol=0,
float Chan3_Max_Tol=0,
float Chan3_Min_Soft=0.2,
float Chan3_Max_Soft=0.2,
const char *version = "PxF_Keyer 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"
)
{
    
    float KeyCenterY = 0.0;
    float KeyCenterU = 0.0;
    float KeyCenterV = 0.0;
    
    float PlotY = 0.0;
    float PlotU = 0.0;
    float PlotV = 0.0;
    
    float KeyCenterRawH = 0.0;
    float KeyCenterH = 0.0;
    float KeyCenterS = 0.0;
    
    float PlotRawH = 0.0;
    float PlotH = 0.0;
    float PlotS = 0.0;
    
    float max = 0.0;
    float min = 0.0;
    float delta = 0.0;
    
    float Plot_max = 0.0;
    float Plot_min = 0.0;
    float Plot_delta = 0.0;
    
    if (enableOSC) {
        Chan1MaxSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan1MaxTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan1MinSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan1MinTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan1PlotLine = Color(1,25,1,1,0,0,1);
    
        Chan2MaxSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan2MaxTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan2MinSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan2MinTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan2PlotLine = Color(1,25,1,1,0,0,1);
    
        Chan3MaxSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan3MaxTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan3MinSoftLine = Color(1, 25, 1, 1, 1, 0, 1, 0);
        Chan3MinTolLine = Color(1, 25, 1, 0, 1, 1, 1, 0);
        Chan3PlotLine = Color(1,25,1,1,0,0,1);
    }
    
    ColorSpace4 = ColorSpace(input, "rgb", KeyerMode, 0.3, 0.59, 0.11);
    
    if (KeyerMode == "rgb") {
        Lookup1 = Lookup(ColorSpace4, (LinearV(x,1,1@(KeyCenterR - Chan1_Min_Tol - Chan1_Min_Soft),0@(KeyCenterR - Chan1_Min_Tol),0@(KeyCenterR + Chan1_Max_Tol),1@(KeyCenterR + Chan1_Max_Tol + Chan1_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterG - Chan2_Min_Tol - Chan2_Min_Soft),0@(KeyCenterG - Chan2_Min_Tol),0@(KeyCenterG + Chan2_Max_Tol),1@(KeyCenterG + Chan2_Max_Tol + Chan2_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterB - Chan3_Min_Tol - Chan3_Min_Soft),0@(KeyCenterB - Chan3_Min_Tol),0@(KeyCenterB + Chan3_Max_Tol),1@(KeyCenterB + Chan3_Max_Tol + Chan3_Max_Soft))), 
                                      LinearV(x,1,0@0,1@1)
                        );
                        
        if (enableOSC) {
            RampChan1 = Ramp(256, 25, 1, 1, 0.5, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0);
            RampChan2 = Ramp(256, 25, 1, 1, 0.5, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0);
            RampChan3 = Ramp(256, 25, 1, 1, 0.5, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0);
        
            RampChan1Pan = Pan(RampChan1, 0, 50, 0, 0.5, 0);
            RampChan2Pan = Pan(RampChan2, 0, 25, 0, 0.5, 0);
            
            Chan1MinSoftPan = Pan(Chan1MinSoftLine, (KeyCenterR - Chan1_Min_Tol - Chan1_Min_Soft) * 255, 50, 0, 0.5, 0);
            Chan1MinTolPan = Pan(Chan1MinTolLine, (KeyCenterR - Chan1_Min_Tol) * 255, 50, 0, 0.5, 0);
            Chan1MaxTolPan = Pan(Chan1MaxTolLine, (KeyCenterR + Chan1_Max_Tol) * 255, 50, 0, 0.5, 0);
            Chan1MaxSoftPan = Pan(Chan1MaxSoftLine, (KeyCenterR + Chan1_Max_Tol + Chan1_Max_Soft) * 255, 50, 0, 0.5, 0);
            Chan1PlotPan = Pan(Chan1PlotLine, PlotR * 255, 50, 0, 0.5, 0);
        
            Chan2MinSoftPan = Pan(Chan2MinSoftLine, (KeyCenterG - Chan2_Min_Tol - Chan2_Min_Soft) * 255, 25, 0, 0.5, 0);
            Chan2MinTolPan = Pan(Chan2MinTolLine, (KeyCenterG - Chan2_Min_Tol) * 255, 25, 0, 0.5, 0);
            Chan2MaxTolPan = Pan(Chan2MaxTolLine, (KeyCenterG + Chan2_Max_Tol) * 255, 25, 0, 0.5, 0);
            Chan2MaxSoftPan = Pan(Chan2MaxSoftLine, (KeyCenterG + Chan2_Max_Tol + Chan2_Max_Soft) * 255, 25, 0, 0.5, 0);
            Chan2PlotPan = Pan(Chan2PlotLine, PlotG * 255, 25, 0, 0.5, 0);
            
            Chan3MinSoftPan = Pan(Chan3MinSoftLine, (KeyCenterB - Chan3_Min_Tol - Chan3_Min_Soft) * 255, 0, 0, 0.5, 0);
            Chan3MinTolPan = Pan(Chan3MinTolLine, (KeyCenterB - Chan3_Min_Tol) * 255, 0, 0, 0.5, 0);
            Chan3MaxTolPan = Pan(Chan3MaxTolLine, (KeyCenterB + Chan3_Max_Tol) * 255, 0, 0, 0.5, 0);
            Chan3MaxSoftPan = Pan(Chan3MaxSoftLine, (KeyCenterB + Chan3_Max_Tol + Chan3_Max_Soft) * 255, 0, 0, 0.5, 0);
            Chan3PlotPan = Pan(Chan3PlotLine, PlotB * 255, 0, 0, 0.5, 0);
        }
        
    }
    else if (KeyerMode == "yuv") {
        
        KeyCenterY = (KeyCenterR * 0.299) + (KeyCenterG * 0.587) + (KeyCenterB * 0.114);
        KeyCenterU = (0.492 * (KeyCenterB - KeyCenterY)) + 0.5;
        KeyCenterV = (0.877 * (KeyCenterR - KeyCenterY)) + 0.5;
        
        PlotY = (PlotR * 0.299) + (PlotG * 0.587) + (PlotB * 0.114);
        PlotU = (0.492 * (PlotB - PlotY)) + 0.5;
        PlotV = (0.877 * (PlotR - PlotY)) + 0.5;
        
        Lookup1 = Lookup(ColorSpace4, (LinearV(x,1,1@(KeyCenterY - Chan1_Min_Tol - Chan1_Min_Soft),0@(KeyCenterY - Chan1_Min_Tol),0@(KeyCenterY + Chan1_Max_Tol),1@(KeyCenterY + Chan1_Max_Tol + Chan1_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterU - Chan2_Min_Tol - Chan2_Min_Soft),0@(KeyCenterU - Chan2_Min_Tol),0@(KeyCenterU + Chan2_Max_Tol),1@(KeyCenterU + Chan2_Max_Tol + Chan2_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterV - Chan3_Min_Tol - Chan3_Min_Soft),0@(KeyCenterV - Chan3_Min_Tol),0@(KeyCenterV + Chan3_Max_Tol),1@(KeyCenterV + Chan3_Max_Tol + Chan3_Max_Soft))), 
                                      LinearV(x,1,0@0,1@1)
                        );
      
         if (enableOSC) {
                RampChan1 = Ramp(256, 25, 1, 1, 0.5, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0);
                RampChan2 = Ramp(256, 25, 1, 1, 0.5, 0.506, 0.698, 0, 1, 0, 0.506, 0.302, 1, 1, 0);
                RampChan3 = Ramp(256, 25, 1, 1, 0.5, 0, 0.792, 0.506, 1, 0, 1, 0.212, 0.506, 1, 0);

                RampChan1Pan = Pan(RampChan1, 0, 50, 0, 0.5, 0);
                RampChan2Pan = Pan(RampChan2, 0, 25, 0, 0.5, 0);

                Chan1MinSoftPan = Pan(Chan1MinSoftLine, (KeyCenterY - Chan1_Min_Tol - Chan1_Min_Soft) * 255, 50, 0, 0.5, 0);
                Chan1MinTolPan = Pan(Chan1MinTolLine, (KeyCenterY - Chan1_Min_Tol) * 255, 50, 0, 0.5, 0);
                Chan1MaxTolPan = Pan(Chan1MaxTolLine, (KeyCenterY + Chan1_Max_Tol) * 255, 50, 0, 0.5, 0);
                Chan1MaxSoftPan = Pan(Chan1MaxSoftLine, (KeyCenterY + Chan1_Max_Tol + Chan1_Max_Soft) * 255, 50, 0, 0.5, 0);
                Chan1PlotPan = Pan(Chan1PlotLine, PlotY * 255, 50, 0, 0.5, 0);

                Chan2MinSoftPan = Pan(Chan2MinSoftLine, (KeyCenterU - Chan2_Min_Tol - Chan2_Min_Soft) * 255, 25, 0, 0.5, 0);
                Chan2MinTolPan = Pan(Chan2MinTolLine, (KeyCenterU - Chan2_Min_Tol) * 255, 25, 0, 0.5, 0);
                Chan2MaxTolPan = Pan(Chan2MaxTolLine, (KeyCenterU + Chan2_Max_Tol) * 255, 25, 0, 0.5, 0);
                Chan2MaxSoftPan = Pan(Chan2MaxSoftLine, (KeyCenterU + Chan2_Max_Tol + Chan2_Max_Soft) * 255, 25, 0, 0.5, 0);
                Chan2PlotPan = Pan(Chan2PlotLine, PlotU * 255, 25, 0, 0.5, 0);

                Chan3MinSoftPan = Pan(Chan3MinSoftLine, (KeyCenterV - Chan3_Min_Tol - Chan3_Min_Soft) * 255, 0, 0, 0.5, 0);
                Chan3MinTolPan = Pan(Chan3MinTolLine, (KeyCenterV - Chan3_Min_Tol) * 255, 0, 0, 0.5, 0);
                Chan3MaxTolPan = Pan(Chan3MaxTolLine, (KeyCenterV + Chan3_Max_Tol) * 255, 0, 0, 0.5, 0);
                Chan3MaxSoftPan = Pan(Chan3MaxSoftLine, (KeyCenterV + Chan3_Max_Tol + Chan3_Max_Soft) * 255, 0, 0, 0.5, 0);
                Chan3PlotPan = Pan(Chan3PlotLine, PlotV * 255, 0, 0, 0.5, 0);
            }
    }

    
    else if (KeyerMode == "hsv") {
        
        max = max3(KeyCenterR,KeyCenterG,KeyCenterB);
        min = min3(KeyCenterR,KeyCenterG,KeyCenterB);
        delta = (max - min);
        KeyCenterRawH = (KeyCenterR == max? (KeyCenterG - KeyCenterB) / delta / 6: KeyCenterG == max? (2 + (KeyCenterB - KeyCenterR) / delta) / 6: KeyCenterB == max? (4 + (KeyCenterR - KeyCenterG) / delta) / 6:0);
        KeyCenterH = KeyCenterRawH < 0? KeyCenterRawH + 1 : KeyCenterRawH;
        KeyCenterS = (max > 0? delta / max:0);
        KeyCenterV = max;
        
        Plot_max = max3(PlotR,PlotG,PlotB);
        Plot_min = min3(PlotR,PlotG,PlotB);
        Plot_delta = (Plot_max - Plot_min);
        PlotRawH = (PlotR == Plot_max? (PlotG - PlotB) / Plot_delta / 6: PlotG == Plot_max? (2 + (PlotB - PlotR) / Plot_delta) / 6: PlotB == Plot_max? (4 + (PlotR - PlotG) / Plot_delta) / 6:0);
        PlotH = PlotRawH < 0? PlotRawH + 1 : PlotRawH;
        PlotS = (Plot_max > 0? Plot_delta / Plot_max:0);
        PlotV = Plot_max;
    
        Lookup1 = Lookup(ColorSpace4, (LinearV(x,1,1@(KeyCenterH - Chan1_Min_Tol - Chan1_Min_Soft),0@(KeyCenterH - Chan1_Min_Tol),0@(KeyCenterH + Chan1_Max_Tol),1@(KeyCenterH + Chan1_Max_Tol + Chan1_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterS - Chan2_Min_Tol - Chan2_Min_Soft),0@(KeyCenterS - Chan2_Min_Tol),0@(KeyCenterS + Chan2_Max_Tol),1@(KeyCenterS + Chan2_Max_Tol + Chan2_Max_Soft))), 
                                      (LinearV(x,1,1@(KeyCenterV - Chan3_Min_Tol - Chan3_Min_Soft),0@(KeyCenterV - Chan3_Min_Tol),0@(KeyCenterV + Chan3_Max_Tol),1@(KeyCenterV + Chan3_Max_Tol + Chan3_Max_Soft))), 
                                      LinearV(x,1,0@0,1@1)                                      
                        );
        if (enableOSC) {
            
            RampChan1Raw = Ramp(256, 25, 1, 1, 0.5, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0);
            RampChan1 = ColorSpace(RampChan1Raw, "hsv", "rgb", 0.3, 0.59, 0.11);
            RampChan2Raw = Ramp(256, 25, 1, 1, 0.5, KeyCenterH, 0, 0.5, 1, 0, KeyCenterH, 1, 1, 1, 0);
            RampChan2 = ColorSpace(RampChan2Raw, "hsv", "rgb", 0.3, 0.59, 0.11);
            RampChan3 = Ramp(256, 25, 1, 1, 0.5, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0);

            RampChan1Pan = Pan(RampChan1, 0, 50, 0, 0.5, 0);
            RampChan2Pan = Pan(RampChan2, 0, 25, 0, 0.5, 0);

            Chan1MinSoftPan = Pan(Chan1MinSoftLine, (KeyCenterH - Chan1_Min_Tol - Chan1_Min_Soft) * 255, 50, 0, 0.5, 0);
            Chan1MinTolPan = Pan(Chan1MinTolLine, (KeyCenterH - Chan1_Min_Tol) * 255, 50, 0, 0.5, 0);
            Chan1MaxTolPan = Pan(Chan1MaxTolLine, (KeyCenterH + Chan1_Max_Tol) * 255, 50, 0, 0.5, 0);
            Chan1MaxSoftPan = Pan(Chan1MaxSoftLine, (KeyCenterH + Chan1_Max_Tol + Chan1_Max_Soft) * 255, 50, 0, 0.5, 0);
            Chan1PlotPan = Pan(Chan1PlotLine, PlotH * 255, 50, 0, 0.5, 0);

            Chan2MinSoftPan = Pan(Chan2MinSoftLine, (KeyCenterS - Chan2_Min_Tol - Chan2_Min_Soft) * 255, 25, 0, 0.5, 0);
            Chan2MinTolPan = Pan(Chan2MinTolLine, (KeyCenterS - Chan2_Min_Tol) * 255, 25, 0, 0.5, 0);
            Chan2MaxTolPan = Pan(Chan2MaxTolLine, (KeyCenterS + Chan2_Max_Tol) * 255, 25, 0, 0.5, 0);
            Chan2MaxSoftPan = Pan(Chan2MaxSoftLine, (KeyCenterS + Chan2_Max_Tol + Chan2_Max_Soft) * 255, 25, 0, 0.5, 0);
            Chan2PlotPan = Pan(Chan2PlotLine, PlotS * 255, 25, 0, 0.5, 0);
            
            Chan3MinSoftPan = Pan(Chan3MinSoftLine, (KeyCenterV - Chan3_Min_Tol - Chan3_Min_Soft) * 255, 0, 0, 0.5, 0);
            Chan3MinTolPan = Pan(Chan3MinTolLine, (KeyCenterV - Chan3_Min_Tol) * 255, 0, 0, 0.5, 0);
            Chan3MaxTolPan = Pan(Chan3MaxTolLine, (KeyCenterV + Chan3_Max_Tol) * 255, 0, 0, 0.5, 0);
            Chan3MaxSoftPan = Pan(Chan3MaxSoftLine, (KeyCenterV + Chan3_Max_Tol + Chan3_Max_Soft) * 255, 0, 0, 0.5, 0);
            Chan3PlotPan = Pan(Chan3PlotLine, PlotV * 255, 0, 0, 0.5, 0);
         }              
    }
    
    Mult1 = Mult(Lookup1, enableChan1, enableChan2, enableChan3, 1, 1);


    Reorder1 = Reorder(Mult1, "rrr");
    Reorder2 = Reorder(Mult1, "ggg");
    Reorder3 = Reorder(Mult1, "bbb");
    if ( ChannelCombine == "max" ) {
    	Max3 = Max(Reorder1, Reorder2, 1, 100);
    	Max4 = Max(Max3, Reorder3, 1, 100);
    } else if ( ChannelCombine == "screen") {
    	Max3 = Screen(Reorder1, Reorder2, 1);
    	Max4 = Screen(Max3, Reorder3, 1);
	}
    Clamp1 = Clamp(Max4, 0, rLo, rLo, 0, 1, rHi, rHi, 1);
    
    if (invertMatte) {
        Invert1 = Invert(Clamp1, "rgba");
    }
    else {
        Invert1 = Clamp1;
    }
    
    SwitchMatte1 = SwitchMatte(input, Invert1, 1, "R", matteMult, 0);
    
    
   
    if (enableOSC) {
       
        Over1 = Over(RampChan1Pan, SwitchMatte1, 1, 0, 0);
        Over2 = Over(RampChan2Pan, Over1, 1, 0, 0);
        Over3 = Over(RampChan3, Over2, 1, 0, 0);
        
        Over4 = Over(Chan1MinSoftPan, Over3, 1, 0, 0);
        Over5 = Over(Chan1MinTolPan, Over4, 1, 0, 0);
        Over6 = Over(Chan1MaxTolPan, Over5, 1, 0, 0);
        Over7 = Over(Chan1MaxSoftPan, Over6, 1, 0, 0);
        
        Over8 = Over(Chan2MinSoftPan, Over7, 1, 0, 0);
        Over9 = Over(Chan2MinTolPan, Over8, 1, 0, 0);
        Over10 = Over(Chan2MaxTolPan, Over9, 1, 0, 0);
        Over11 = Over(Chan2MaxSoftPan, Over10, 1, 0, 0);
        
        Over12 = Over(Chan3MinSoftPan, Over11, 1, 0, 0);
        Over13= Over(Chan3MinTolPan, Over12, 1, 0, 0);
        Over14 = Over(Chan3MaxTolPan, Over13, 1, 0, 0);
        Over15 = Over(Chan3MaxSoftPan, Over14, 1, 0, 0);
        
        Over16 = Over(Chan1PlotPan, Over15, 1, 0, 0);
        Over17 = Over(Chan2PlotPan, Over16, 1, 0, 0);
        Over18 = Over(Chan3PlotPan, Over17, 1, 0, 0);
        
        
    }
    else {
        Over18 = SwitchMatte1;
    }
    

    return Over18;
}

