nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_Filler",PxF_Filler());
    nuiPopToolBox();
nuiPopMenu();

nuiDefSlider("PxF_Filler.xPixels",0,200,0.1);
nuiDefSlider("PxF_Filler.yPixels",0,200,0.1);
nuiDefSlider("PxF_Filler.iterations",1,20,1);
nuxDefToggle("PxF_Filler.invertMatte");
nuxDefToggle("PxF_Filler.softEdges");
nuxDefToggle("PxF_Filler.ignoreAlpha");
nuxDefRadioBtnOCtrl("PxF_Filler.matteChannel",1, 1, 0, "R|ux/radio/radio_red", "G|ux/radio/radio_green", "B|ux/radio/radio_blue", "A|ux/radio/radio_alpha" );

nuxDefTextCtrl("PxF_Filler.version", 1);