/* PxF_Filler 1.0.2 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	Interpolate parts of an image using a matte of the area to interpolate and a gaussian filter.

Used for:
	Erasing unwanted parts of images like tracking markers.
	Creating clean plates to be used with PxF_ScreenClean.
	Wire removal.
	Stretching the edges of a layer.

Controls:
	pixels:
		How many pixels the parts of the image at the edge of the holeMatte will be stretched (per
		iteration).
	iterations:
		How many times the stretching will be repeated. Use a low number of iterations for coarse
		interpolation. Use a high number of iterations for more precision, but at the risk of having
		noise in the interpolation if the original image is noisy or high frequency.

	invertMatte:
		Inverts the holeMatte. By default, invertMatte "off" expects the area to be interpolated to
		be white and the area to be left untouched to be black.

	softEdges:
		"On" gives a smoother interpolation.
		"Off" requires less pixels and/or iterations to interpolate a large area.

	ignoreAlpha:
		"Off" interpolation is applied to RGBA channels of the original image.
		"On" interpolation is applied to RGB channels of the original image, leaving the alpha
		channel untouched.
	
Changes in 1.0.1:
	Fixed a bug where macro would fail if not attached to another node on creation.
	Added option to select which channel to use for hole matte instead of forcing "alpha"

Changes in 1.0.2:
	Fixed the "too many recursive evaluations" bug.

*/




image PxF_Filler(
image Image=0,
image HoleMatte=0,
float xPixels=50,
float yPixels=xPixels,
int iterations = 1,
int invertMatte = 0,
int softEdges = 1,
int ignoreAlpha = 0,
char *matteChannel = "A",
const char *version = "PxF_Filler 1.0.2 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"
)
{
	float divPercent = 100.0;
	//int originalBytes = Image.bytes;
	
	if (softEdges) {
		divPercent = 99.99;
	}
	
	
	if (ignoreAlpha) {
		SetAlpha1 = SetAlpha(Image, 1);
	} else {
		SetAlpha1 = Image;
	}
  
    if (matteChannel == "A") {
    	Reorder1 = Reorder(HoleMatte, "aaaa");
    } else if (matteChannel == "R") {
    	Reorder1 = Reorder(HoleMatte, "rrrr");
	} else if (matteChannel == "G") {
    	Reorder1 = Reorder(HoleMatte, "gggg"); 
	} else if (matteChannel == "B") {
    	Reorder1 = Reorder(HoleMatte, "bbbb");
    }
  
  
	if (invertMatte == 0) {
    		Invert1 = Invert(Reorder1, "rgba");
    		HolePunch = Outside(SetAlpha1, Reorder1, 1);
	}
	else {
		Invert1 = Reorder1;
		HolePunch = Inside(SetAlpha1, Reorder1, 1);
	} 
    

    
    
    Bytes2 = Bytes(Invert1, 4);
    
    Looper = Bytes(HolePunch, 4);
    Looper2 = Bytes2;
    
    for (int i=0; i<iterations; ++i) {
		Blur1 = Blur(Looper, xPixels, yPixels, 0, "gauss", xFilter, "rgba");
		Blur2 = Blur(Looper2, xPixels, yPixels, 0, "gauss", xFilter, "rgba");
		Looper = IDiv(Blur1, Blur2, 1, divPercent, 1);
		if (i != iterations -1) {
			Looper2 = IDiv(Blur2, Blur2, 1, divPercent, 1);
		}
		
    }
    
    KeyMix1 = KeyMix(Looper, SetAlpha1, Bytes2, 1, "A", 100, 0);
    
    if (ignoreAlpha) {
    	Bytes3 = Bytes(KeyMix1, originalBytes);
    	Output1 = SwitchMatte(Bytes3, Image, 1, "A", 0, 0);
    } else {
    	Output1 = Bytes(KeyMix1, Image.bytes);
    }


    
    return Output1;
}

