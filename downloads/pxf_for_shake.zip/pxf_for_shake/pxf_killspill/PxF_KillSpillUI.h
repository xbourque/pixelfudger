nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_KillSpill",PxF_KillSpill());
    nuiPopToolBox();
nuiPopMenu();

nuxDefRadioBtnOCtrl("PxF_KillSpill.BackColor",1, 1, 0, "R|ux/radio/radio_red", "G|ux/radio/radio_green", "B|ux/radio/radio_blue");

nuiDefSlider("PxF_KillSpill.Mix",0,100,0.1);

nuxDefTextCtrl("PxF_KillSpill.version", 1);