/* PxF_KillSpill 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	Neutralizes the backing color on chroma-key shots.

Used for:
	Spill suppression.

Controls:
	BackColor:
		Select the type of chroma key screen.
	Mix:
		Adjusts the mix of the 2 "minor" channels by which the "major" channel is limited. (slide 
		left and right until it looks "good"). On some shots, a mix value larger than 100 might be
		required.
	
	Tip:
		If KillSpill turns your blue screen to green (or your green screen to red, etc...) try
		chaining 2 KillSpill nodes back to back to kill the remaining color.

*/

image PxF_KillSpill(
image Foreground=0,
const char *BackColor = "B",
float Mix=50,
const char *version = "PxF_KillSpill 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"
)
{
    if( BackColor == "B") {
        hi_chan = Reorder(Foreground, "bbb");
        lo2_chan = Reorder(Foreground, "ggg");
        lo1_chan = Reorder(Foreground, "rrr");
    } else if ( BackColor == "G") {
        hi_chan = Reorder(Foreground, "ggg");
        lo2_chan = Reorder(Foreground, "bbb");
        lo1_chan = Reorder(Foreground, "rrr");
    } else if ( BackColor == "R") {
        hi_chan = Reorder(Foreground, "rrr");
        lo2_chan = Reorder(Foreground, "ggg");
        lo1_chan = Reorder(Foreground, "bbb");
    }
    Mix1 = Mix(lo1_chan, lo2_chan, 1, Mix, "rgba");
    Min1 = Min(hi_chan, Mix1, 1, 100);

    if( BackColor == "B") {
        Copy1 = Copy(Foreground, Min1, 1, "b", 0);
    } else if ( BackColor == "G") {
        Copy1 = Copy(Foreground, Min1, 1, "g", 0);
    } else if ( BackColor == "R") {
        Copy1 = Copy(Foreground, Min1, 1, "r", 0);
    }
    
    ISub1 = ISub(Foreground, Copy1, 1, 100);
    Monochrome1 = Monochrome(ISub1, 0.3, 0.59, 0.11);
    IAdd1 = IAdd(Monochrome1, Copy1, 1, 100);
    
    return IAdd1;
}

