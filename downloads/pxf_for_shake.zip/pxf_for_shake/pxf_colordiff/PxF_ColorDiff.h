/* PxF_ColorDiff 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com

Description:
	Basic color channel difference keyer.

Used for:
	Pulling a quick matte from a green, blue or red screen image.

Controls:
	screenColor:
		Select the color channel to be keyed (the "major" channel).
	mixMode:
		Select how the "minor" channels will be blended together before being subtracted from the
		"major" channel.

	mix:
		If the mixMode is "mix" then this drives the percentage of mix between the "minor" channels.
		If the mixMode is "max", then this has no effect.

	screenRangeLo:
		Adjust the black point of the alpha channel.

	screenRangeHi:
		Adjust the white point of the alpha channel.

	matteMult:
		This multiplies the original image by the alpha channel.
	
	invertMatte:
		This inverts the alpha channel.
*/


image PxF_ColorDiff(
image In=0,
char *screenColor = "G",
int mixMode = 0,
float mix = 50,
float screenRangeLo = 0,
float screenRangeHi = 1,
int matteMult = 1,
int invertMatte = 0,
const char *version = "PxF_ColorDiff 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"

)
{
    
    blue_chan = Reorder(In, "000b");
    green_chan = Reorder(In, "000g");
    red_chan = Reorder(In, "000r");
    
    if( screenColor == "G") {
    	if ( mixMode == 0) {
        	Max1 = Max(red_chan, blue_chan, 1, 100);
        } else if (mixMode == 1) {
        	Max1 = Mix(red_chan, blue_chan, 1, mix, "a");
        }
        ISub1 = ISub(green_chan, Max1, 1, 100);
    }
    else if (screenColor == "B") {
        if ( mixMode == 0) {
        	Max1 = Max(red_chan, green_chan, 1, 100);
        } else if (mixMode == 1) {
        	Max1 = Mix(red_chan, green_chan, 1, mix, "a");
        }
        ISub1 = ISub(blue_chan, Max1, 1, 100);
    }
    else if (screenColor == "R") {
        if ( mixMode == 0) {
        	Max1 = Max(blue_chan, green_chan, 1, 100);
        } else if (mixMode == 1) {
        	Max1 = Mix(blue_chan, green_chan, 1, mix, "a");
        }
        ISub1 = ISub(red_chan, Max1, 1, 100);
    }
    Clamp2 = Clamp(ISub1, 0, 0, 0, 0, 1, 1, 1, 1);
    Invert3 = Invert(Clamp2, "a");
	Expand1 = Expand(Invert3, 0, 0, 0, screenRangeLo, 1, 1, 1, screenRangeHi);
	Clamp1 = Clamp(Expand1, 0, 0, 0, 0, 1, 1, 1, 1);
	SwitchMatte1 = SwitchMatte(In, Clamp1, 1, "A", matteMult, invertMatte);



    return SwitchMatte1;
}

