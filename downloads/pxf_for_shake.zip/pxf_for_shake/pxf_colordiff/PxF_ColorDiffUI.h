nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_ColorDiff",PxF_ColorDiff());
    nuiPopToolBox();
nuiPopMenu();

nuxDefRadioBtnOCtrl("PxF_ColorDiff.screenColor",1, 1, 0, "R|ux/radio/radio_red", "G|ux/radio/radio_green", "B|ux/radio/radio_blue");

//nuxDefMultiChoice("PxF_ColorDiff.screenColor","red|green|blue");
//nuxDefRadioBtnOCtrl("PxF_ColorDiff.screenColor", 0, 1, 0, "0|r", "1|g", "2|b");
nuxDefMultiChoice("PxF_ColorDiff.mixMode","max|mix");
nuxDefRadioBtnOCtrl("PxF_ColorDiff.mixMode", 0, 1, 0, "0|max", "1|mix");
nuiDefSlider("PxF_ColorDiff.mix",0,100,0);
nuiDefSlider("PxF_ColorDiff.screenRangeLo",0,1,0);
nuiDefSlider("PxF_ColorDiff.screenRangeHi",0,1,0);
nuxDefToggle("PxF_ColorDiff.matteMult");
nuxDefToggle("PxF_ColorDiff.invertMatte");
nuxDefTextCtrl("PxF_ColorDiff.version", 1);
