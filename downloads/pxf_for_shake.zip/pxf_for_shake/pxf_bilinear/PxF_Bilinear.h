/* PxF_Bilinear 1.0 - (c) 2007 - PixelFudger
   Contact: Xavier Bourque - xbourque@gmail.com
   Huge thanks to Olli Leppanen on the Shake List Server for coming up with the proper way to
   put the bilinear formula into a WarpX node.

Description:
	"Montreal-style" bilinear corner pin.

Used when:
	Unlike Shake's corner pin, this one doesn't attempt to simulate perspective. It just moves the
	corners. This means that if you move one side of the image, the other side stays put. One could
	also tile them together to simulate a deform patch (but would be slooooow!).
	
Controls:
	LLX:
		Lower left X position. 
	LLY:
		Lower left Y position. 
	LRX:
		Lower right X position. 
	LRY:
		Lower right Y position. 
	URX:
		Upper right X position. 
	URY:
		Upper right Y position. 
	ULX:
		Upper left X position. 
	ULY:
		Upper left Y position. 
*/



image PxF_Bilinear(
image In=0,
float LLX = 0,
float LLY = 0,
float LRX = width,
float LRY = 0,
float URX = width,
float URY = height,
float ULX = 0,
float ULY = height,
const char *version = "PxF_Bilinear 1.0 - (c) 2007 - Xavier Bourque - www.pixelfudger.com"


)
{
	
	 WarpX1 = WarpX(In, 1, 
	 	{{ xA = ((y - LLY) / (ULY - LLY)) * (ULX - LLX) + LLX;
	 	   xB = ((y - LRY) / (URY - LRY)) * (URX - LRX) + LRX;
		   u = (x - xA) / (xB - xA);
		   u * width }}, 
	     	{{ yA = ((x - LLX) / (LRX - LLX)) * (LRY - LLY) + LLY;
	 	   yB = ((x - ULX) / (URX - ULX)) * (URY - ULY) + ULY;
		   v = (y - yA) / (yB - yA);
		   v * height }}, 

	     0, xDelta);
   
    return WarpX1;
}


