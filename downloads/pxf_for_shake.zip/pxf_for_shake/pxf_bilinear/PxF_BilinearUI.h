nuiPushMenu("Tools");
    nuiPushToolBox("PixelFudger");
        nuiToolBoxItem("PxF_Bilinear",PxF_Bilinear());
    nuiPopToolBox();
nuiPopMenu();


/*
nuiPushControlGroup("PxF_Bilinear.Corner Controls");
	nuiGroupControl("PxF_Bilinear.x0");
	nuiGroupControl("PxF_Bilinear.y0");
	nuiGroupControl("PxF_Bilinear.x1");
	nuiGroupControl("PxF_Bilinear.y1");
	nuiGroupControl("PxF_Bilinear.x2");
	nuiGroupControl("PxF_Bilinear.y2");
	nuiGroupControl("PxF_Bilinear.x3");
	nuiGroupControl("PxF_Bilinear.y3");
nuiPopControlGroup();
*/
/*
nuiDefSlider("PxF_Bilinear.LLX",		0,		width);
nuiDefSlider("PxF_Bilinear.LLY",		0,		height);
nuiDefSlider("PxF_Bilinear.LRX",		0,		width);
nuiDefSlider("PxF_Bilinear.LRY",		0,		height);
nuiDefSlider("PxF_Bilinear.URX",		0,		width);
nuiDefSlider("PxF_Bilinear.URY",		0,		height);
nuiDefSlider("PxF_Bilinear.ULX",		0,		width);
nuiDefSlider("PxF_Bilinear.ULY",		0,		height);*/

nuiAddPointOsc("PxF_Bilinear.LL");
nuiAddPointOsc("PxF_Bilinear.LR");
nuiAddPointOsc("PxF_Bilinear.UR");
nuiAddPointOsc("PxF_Bilinear.UL");
nuxDefTextCtrl("PxF_Bilinear.version", 1);

