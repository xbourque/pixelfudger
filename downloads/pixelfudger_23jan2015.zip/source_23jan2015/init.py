import nuke

nuke.pluginAddPath('pixelfudger')