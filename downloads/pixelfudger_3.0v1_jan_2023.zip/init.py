import nuke

nuke.pluginAddPath('pixelfudger3')